package com.gdpdemo.GDPSprint1Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class GdpSprint1ProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(GdpSprint1ProjectApplication.class, args);
	}

}
